<template>
  <main>
    <KanbanBoard />
  </main>
</template>

<script setup>
import KanbanBoard from '@/components/KanbanBoard.vue'
</script>
